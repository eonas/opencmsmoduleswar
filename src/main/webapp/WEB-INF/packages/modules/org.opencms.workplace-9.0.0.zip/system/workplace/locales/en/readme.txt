*** DON'T DELETE THIS DIRECTORY! ***

It is required for locale support.